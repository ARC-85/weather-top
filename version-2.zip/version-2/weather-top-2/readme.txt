Weather Top is a handy interface for entering and displaying various readings from an array of weather stations. Upon entering the “Start” page, use the top menu to navigate to the “Dashboard”. The main dashboard presents each weather station, including its latitude and longitude details. By clicking the “View” button for any station, a list of readings will be displayed, including a summary of the latest readings. Data for each station includes: 
*Weather type (code and corresponding description)
*Temperature (Celsius and Fahrenheit)
*Wind Speed (km/hr and Beaufort)
*Pressure (hPa)
Use the “Dashboard” button on the main menu to navigate back to other stations, or the “Weather Top” button to return to the Start page.  
