package models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import play.db.jpa.Model;

@Entity
public class Reading extends Model
{
  public int code;
  public double temperature;
  public double windSpeed;
  public int pressure;

  public Reading(int code, double temperature, double windSpeed, int pressure)
  {
    this.code = code;
    this.temperature = temperature;
    this.windSpeed = windSpeed;
    this.pressure = pressure;
  }

  public int getCode() {
    return code;
  }

  public double getTemp() {
    return temperature;
  }

  public double getWind() {
    return windSpeed;
  }

  public int getPressure() {
    return pressure;
  }

}
